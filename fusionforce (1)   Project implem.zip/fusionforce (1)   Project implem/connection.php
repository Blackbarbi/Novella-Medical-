<?php
$servername = "127.0.0.1"; 
$username = "u152458561_nhoste";
$password = "Sephor05"; // your new password
$dbname = "u152458561_nhoste";

$database = new mysqli($servername, $username, $password, $dbname);

if ($database->connect_error) {
    die("Database connection failed: " . $database->connect_error);
}
?>
