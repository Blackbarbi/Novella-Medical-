<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title></title>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Custom Styles -->
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }

        .login-container {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #fff 50%, #6a0dad 50%);
        }

        .login-card {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 450px;
            padding: 40px;
            position: relative;
            z-index: 1;
        }

        .login-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            border-radius: 15px;
            background: rgba(106, 13, 173, 0.05);
            z-index: -1;
        }

        .header-text {
            font-size: 2rem;
            font-weight: 700;
            color: #6a0dad;
            text-align: center;
        }

        .sub-text {
            font-size: 1rem;
            color: #555;
            text-align: center;
            margin-bottom: 30px;
        }

        .form-label {
            font-weight: 500;
            color: #6a0dad;
        }

        .input-text {
            width: 100%;
            padding: 12px 15px;
            margin: 5px 0 15px 0;
            border-radius: 8px;
            border: 1px solid #ccc;
            outline: none;
            transition: 0.3s;
        }

        .input-text:focus {
            border-color: #6a0dad;
            box-shadow: 0 0 5px rgba(106, 13, 173, 0.3);
        }

        .login-btn {
            background-color: #6a0dad;
            color: #fff;
            font-weight: 600;
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 8px;
            transition: 0.3s;
        }

        .login-btn:hover {
            background-color: #9b5de5;
        }

        .hover-link1 {
            color: #6a0dad;
            text-decoration: none;
            font-weight: 500;
        }

        .hover-link1:hover {
            color: #9b5de5;
            text-decoration: underline;
        }

        .error-label {
            color: #ff3e3e;
            font-weight: 500;
            text-align: center;
            display: block;
            margin-bottom: 15px;
        }

        @media (max-width: 768px) {
            .login-card {
                padding: 30px 20px;
            }

            .header-text {
                font-size: 1.7rem;
            }
        }

        /* Back Button */
        .back-btn {
            display: inline-block;
            margin-bottom: 15px;
            background-color: #f0e6ff;
            color: #6a0dad;
            padding: 10px 15px;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 500;
        }

        .back-btn:hover {
            background-color: #e0d1ff;
            color: #6a0dad;
        }
    </style>
</head>

<body>

    <?php
    session_start();
    $_SESSION["user"] = "";
    $_SESSION["usertype"] = "";

    date_default_timezone_set('Asia/Kolkata');
    $_SESSION["date"] = date('Y-m-d');

    include("connection.php");

    if ($_POST) {
        $email = $_POST['useremail'];
        $password = $_POST['userpassword'];

        $error = '<span class="error-label">&nbsp;</span>';

        $result = $database->query("select * from webuser where email='$email'");
        if ($result->num_rows == 1) {
            $utype = $result->fetch_assoc()['usertype'];
            if ($utype == 'p') {
                $checker = $database->query("select * from patient where pemail='$email' and ppassword='$password'");
                if ($checker->num_rows == 1) {
                    $_SESSION['user'] = $email;
                    $_SESSION['usertype'] = 'p';
                    header('location: patient/index.php');
                } else {
                    $error = '<span class="error-label">Wrong credentials: Invalid email or password</span>';
                }
            } elseif ($utype == 'a') {
                $checker = $database->query("select * from admin where aemail='$email' and apassword='$password'");
                if ($checker->num_rows == 1) {
                    $_SESSION['user'] = $email;
                    $_SESSION['usertype'] = 'a';
                    header('location: admin/index.php');
                } else {
                    $error = '<span class="error-label">Wrong credentials: Invalid email or password</span>';
                }
            } elseif ($utype == 'd') {
                $checker = $database->query("select * from doctor where docemail='$email' and docpassword='$password'");
                if ($checker->num_rows == 1) {
                    $_SESSION['user'] = $email;
                    $_SESSION['usertype'] = 'd';
                    header('location: doctor/index.php');
                } else {
                    $error = '<span class="error-label">Wrong credentials: Invalid email or password</span>';
                }
            }
        } else {
            $error = '<span class="error-label">No account found with this email.</span>';
        }
    } else {
        $error = '<span class="error-label">&nbsp;</span>';
    }
    ?>

    <div class="login-container">
        <div class="login-card">

            <!-- Back Button -->
            

            <p class="header-text">Welcome Back!</p>
            <p class="sub-text">Login with your details to continue</p>

            <form action="" method="POST">
                <label for="useremail" class="form-label">Email:</label>
                <input type="email" name="useremail" class="input-text" placeholder="Email Address" required>

                <label for="userpassword" class="form-label">Password:</label>
                <input type="password" name="userpassword" class="input-text" placeholder="Password" required>

                <?php echo $error; ?>

                <input type="submit" value="Login" class="login-btn btn-primary btn">

                <p class="sub-text mt-3">Don't have an account? 
                    <a href="signup.php" class="hover-link1">Sign Up</a>
                </p>
            </form>
        </div>
    </div>

</body>

</html>

