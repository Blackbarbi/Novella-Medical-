<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="../css/animations.css">  
<link rel="stylesheet" href="../css/main.css">  
<link rel="stylesheet" href="../css/admin.css">

<title>Settings</title>

<style>
    /* ================= Animations ================= */
    .dashbord-tables { animation: transitionIn-Y-over 0.5s; }
    .filter-container { animation: transitionIn-X 0.5s; }
    .sub-table { animation: transitionIn-Y-bottom 0.5s; }

    /* ================= Purple Theme ================= */
    :root { 
        --primary-color: #8e44ad; 
        --primary-hover: #732d91; 
    }
    .btn-primary, .btn-primary-soft {
        background-color: var(--primary-color) !important;
        border: none !important;
        color: #fff !important;
    }
    .btn-primary:hover { background-color: var(--primary-hover) !important; }
    .btn-primary-soft:hover { background-color: #b266d1 !important; }

    /* ================= Hamburger Menu ================= */
    .hamburger {
        display: none;
        cursor: pointer;
        position: fixed;
        top: 15px;
        left: 15px;
        z-index: 1001;
        background: var(--primary-color);
        border: none;
        color: white;
        padding: 10px 12px;
        border-radius: 6px;
        font-size: 20px;
    }
    .hamburger:hover { background: var(--primary-hover); }

    /* ================= Sidebar for mobile ================= */
    .menu { transition: transform 0.3s ease-in-out; }
    .menu.active { transform: translateX(0); }

    @media screen and (max-width: 768px) {
        .menu {
            position: fixed;
            top: 0;
            left: 0;
            width: 220px;
            height: 100%;
            background-color: white;
            transform: translateX(-100%);
            z-index: 1000;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }
        .hamburger { display: block; }
        .dash-body { margin-left: 0 !important; padding: 15px; }
        .filter-container .dashboard-items { width: 90% !important; margin: 0 auto; }
    }

    /* ================= Popup overlay ================= */
    .overlay {
        position: fixed; top: 0; left: 0;
        width: 100%; height: 100%;
        background: rgba(0,0,0,0.6);
        z-index: 2000;
        display: flex; align-items: center; justify-content: center;
    }
    .popup {
        background: #fff;
        border-radius: 12px;
        padding: 25px;
        width: 50%;
        max-height: 90%;
        overflow-y: auto;
        position: relative;
    }
    .popup .close {
        position: absolute; top: 10px; right: 20px;
        text-decoration: none; font-size: 28px; color: var(--primary-color);
    }
    .popup h2 { color: var(--primary-color); }

    @media screen and (max-width: 768px) {
        .popup { width: 95%; height: 95%; border-radius: 10px; padding: 15px; overflow-y: auto; }
        .popup .close { font-size: 30px; top: 15px; right: 15px; }
    }

    /* ================= Scrollable table/cards ================= */
    .scroll { overflow-x: auto; }
</style>
</head>
<body>

<?php
session_start();
if(isset($_SESSION["user"])){
    if(($_SESSION["user"])=="" or $_SESSION['usertype']!='p'){
        header("location: ../login.php");
    }else{
        $useremail=$_SESSION["user"];
    }
}else{
    header("location: ../login.php");
}

include("../connection.php");
$sqlmain= "select * from patient where pemail=?";
$stmt = $database->prepare($sqlmain);
$stmt->bind_param("s",$useremail);
$stmt->execute();
$result = $stmt->get_result();
$userfetch=$result->fetch_assoc();
$userid= $userfetch["pid"];
$username=$userfetch["pname"];
?>

<!-- ================= Hamburger Menu Button ================= -->
<button class="hamburger" onclick="toggleMenu()">☰</button>

<div class="container">
    <!-- ================= Sidebar Menu ================= -->
    <div class="menu" id="sidebar">
        <table class="menu-container" border="0">
            <tr>
                <td style="padding:10px" colspan="2">
                    <table border="0" class="profile-container">
                        <tr>
                            <td width="30%" style="padding-left:20px">
                                <img src="../img/user.png" alt="" width="100%" style="border-radius:50%">
                            </td>
                            <td style="padding:0px;margin:0px;">
                                <p ></p>
                                <p class="profile-subtitle"><?php echo substr($useremail,0,22) ?></p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <a href="../logout.php" ><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr class="menu-row">
                <td class="menu-btn menu-icon-home"><a href="index.php" class="non-style-link-menu"><div><p class="menu-text">Home</p></div></a></td>
            </tr>
            <tr class="menu-row">
                <td class="menu-btn menu-icon-doctor"><a href="doctors.php" class="non-style-link-menu"><div><p class="menu-text">All Doctors</p></div></a></td>
            </tr>
            <tr class="menu-row">
                <td class="menu-btn menu-icon-session"><a href="schedule.php" class="non-style-link-menu"><div><p class="menu-text">Scheduled Sessions</p></div></a></td>
            </tr>
            <tr class="menu-row">
                <td class="menu-btn menu-icon-appoinment"><a href="appointment.php" class="non-style-link-menu"><div><p class="menu-text">My Bookings</p></div></a></td>
            </tr>
            <tr class="menu-row">
                <td class="menu-btn menu-icon-settings menu-active menu-icon-settings-active"><a href="settings.php" class="non-style-link-menu non-style-link-menu-active"><div><p class="menu-text">Settings</p></div></a></td>
            </tr>
        </table>
    </div>

    <!-- ================= Dashboard Body ================= -->
    <div class="dash-body" style="margin-top: 15px">
        <table border="0" width="100%" style="border-spacing:0;margin:0;padding:0;">
            <tr>
                
                <td>
                    <p style="font-size:23px;padding-left:12px;font-weight:600;"></p>
                </td>
                <td width="15%">
                    <p style="font-size:14px;color:#777;padding:0;margin:0;text-align:right;">Today's Date</p>
                    <p class="heading-sub12" style="padding:0;margin:0;">
                        <?php 
                        date_default_timezone_set('Asia/Kolkata');
                        $today = date('Y-m-d');
                        echo $today;
                        ?>
                    </p>
                </td>
                <td width="10%">
                    <button class="btn-label" style="display:flex;justify-content:center;align-items:center;"><img src="../img/calendar.svg" width="100%"></button>
                </td>
            </tr>

            <tr>
                <td colspan="4">
                    <center>
                    <table class="filter-container scroll" style="border:none;">
                        <tr>
                            <td style="width:25%;">
                                <a href="?action=edit&id=<?php echo $userid ?>&error=0" class="non-style-link">
                                <div class="dashboard-items setting-tabs" style="padding:20px;margin:auto;width:95%;display:flex">
                                    <div class="btn-icon-back dashboard-icons-setting" style="background-image:url('../img/icons/doctors-hover.svg');"></div>
                                    <div>
                                        
                                        <div class="h3-dashboard" style="font-size:15px;">Edit your Account Details & Change Password</div>
                                    </div>
                                </div></a>
                            </td>
                        </tr>
                        <tr><td colspan="4" style="height:10px;"></td></tr>
                        <tr>
                            <td style="width:25%;">
                                <a href="?action=view&id=<?php echo $userid ?>" class="non-style-link">
                                <div class="dashboard-items setting-tabs" style="padding:20px;margin:auto;width:95%;display:flex;">
                                    <div class="btn-icon-back dashboard-icons-setting" style="background-image:url('../img/icons/view-iceblue.svg');"></div>
                                    <div>
                                        
                                        <div class="h3-dashboard" style="font-size:15px;">View Personal information About Your Account</div>
                                    </div>
                                </div></a>
                            </td>
                        </tr>
                        <tr><td colspan="4" style="height:10px;"></td></tr>
                        <tr>
                            <td style="width:25%;">
                                <a href="?action=drop&id=<?php echo $userid.'&name='.$username ?>" class="non-style-link">
                                <div class="dashboard-items setting-tabs" style="padding:20px;margin:auto;width:95%;display:flex;">
                                    <div class="btn-icon-back dashboard-icons-setting" style="background-image:url('../img/icons/patients-hover.svg');"></div>
                                    <div>
                                       
                                        <div class="h3-dashboard" style="font-size:15px;">Delete Permanently  your Account</div>
                                    </div>
                                </div></a>
                            </td>
                        </tr>
                    </table>
                    </center>
                </td>
            </tr>
        </table>
    </div>
</div>

<!-- ================= Toggle Sidebar Script ================= -->
<script>
function toggleMenu(){
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('active');
}
</script>

<?php
if($_GET){
    $id=$_GET["id"] ?? null;
    $action=$_GET["action"] ?? null;

    if($action=='drop'){
        $nameget=$_GET["name"];
        echo '
        <div id="popup1" class="overlay">
            <div class="popup">
                <center>
                    <h2>Are you sure?</h2>
                    <a class="close" href="settings.php">&times;</a>
                    <div class="content">You want to delete Your Account<br>('.substr($nameget,0,40).').</div>
                    <div style="display:flex;justify-content:center;">
                        <a href="delete-account.php?id='.$id.'" class="non-style-link"><button class="btn-primary btn" style="margin:10px;padding:10px;">Yes</button></a>
                        <a href="settings.php" class="non-style-link"><button class="btn-primary btn" style="margin:10px;padding:10px;">No</button></a>
                    </div>
                </center>
            </div>
        </div>';
    }
    elseif($action=='view'){
        $sqlmain= "select * from patient where pid=?";
        $stmt = $database->prepare($sqlmain);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row=$result->fetch_assoc();
        $name=$row["pname"];
        $email=$row["pemail"];
        $address=$row["paddress"];
        $dob=$row["pdob"];
        $nic=$row['pnic'];
        $tele=$row['ptel'];
        echo '
        <div id="popup1" class="overlay">
            <div class="popup">
                <center>
                    <a class="close" href="settings.php">&times;</a>
                    <table width="80%" class="sub-table scrolldown add-doc-form-container" border="0">
                        <tr><td colspan="2"><p style="font-size:25px;font-weight:500;text-align:left;">View Details.</p><br></td></tr>
                        <tr><td colspan="2">Name: '.$name.'<br><br></td></tr>
                        <tr><td colspan="2">Email: '.$email.'<br><br></td></tr>
                        <tr><td colspan="2">NIC: '.$nic.'<br><br></td></tr>
                        <tr><td colspan="2">Telephone: '.$tele.'<br><br></td></tr>
                        <tr><td colspan="2">Address: '.$address.'<br><br></td></tr>
                        <tr><td colspan="2">Date of Birth: '.$dob.'<br><br></td></tr>
                        <tr><td colspan="2"><a href="settings.php"><input type="button" value="OK" class="login-btn btn-primary-soft btn"></a></td></tr>
                    </table>
                </center>
            </div>
        </div>';
    }
    elseif($action=='edit'){
        $sqlmain= "select * from patient where pid=?";
        $stmt = $database->prepare($sqlmain);
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $row=$result->fetch_assoc();
        $name=$row["pname"];
        $email=$row["pemail"];
        $address=$row["paddress"];
        $nic=$row['pnic'];
        $tele=$row['ptel'];
        $error_1=$_GET["error"] ?? 0;
        $errorlist= array(
            '1'=>'<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Already have an account for this Email address.</label>',
            '2'=>'<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;">Password Conformation Error! Reconform Password</label>',
            '3'=>'<label for="promter" class="form-label" style="color:rgb(255, 62, 62);text-align:center;"></label>',
            '4'=>"",
            '0'=>'',
        );

        if($error_1!='4'){
            echo '
            <div id="popup1" class="overlay">
                <div class="popup scroll">
                    <center>
                        <a class="close" href="settings.php">&times;</a>
                        <table width="90%" class="sub-table add-doc-form-container" border="0">
                            <tr><td colspan="2">'.$errorlist[$error_1].'</td></tr>
                            <tr><td colspan="2"><p style="font-size:25px;font-weight:500;text-align:left;">Edit User Account Details.</p>User ID : '.$id.' (Auto Generated)<br><br></td></tr>
                            <tr><td colspan="2">
                                <form action="edit-user.php" method="POST" class="add-new-form">
                                <input type="hidden" value="'.$id.'" name="id00">
                                <input type="hidden" name="oldemail" value="'.$email.'" >
                                <label>Email: </label><br>
                                <input type="email" name="email" class="input-text" placeholder="Email Address" value="'.$email.'" required><br><br>
                                <label>Name: </label><br>
                                <input type="text" name="name" class="input-text" placeholder="Name" value="'.$name.'" required><br><br>
                                <label>NIC: </label><br>
                                <input type="text" name="nic" class="input-text" placeholder="NIC Number" value="'.$nic.'" required><br><br>
                                <label>Telephone: </label><br>
                                <input type="tel" name="Tele" class="input-text" placeholder="Telephone Number" value="'.$tele.'" required><br><br>
                                <label>Address: </label><br>
                                <input type="text" name="address" class="input-text" placeholder="Address" value="'.$address.'" required><br><br>
                                <label>Password: </label><br>
                                <input type="password" name="password" class="input-text" placeholder="Define a Password" required><br><br>
                                <label>Conform Password: </label><br>
                                <input type="password" name="cpassword" class="input-text" placeholder="Conform Password" required><br><br>
                                <input type="reset" value="Reset" class="login-btn btn-primary-soft btn" >&nbsp;&nbsp;&nbsp;
                                <input type="submit" value="Save" class="login-btn btn-primary btn">
                                </form>
                            </td></tr>
                        </table>
                    </center>
                </div>
            </div>';
        }
    }
}
?>
</body>
</html>

