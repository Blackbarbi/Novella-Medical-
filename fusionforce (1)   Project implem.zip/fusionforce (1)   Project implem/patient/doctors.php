<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="../css/animations.css">  
<link rel="stylesheet" href="../css/main.css">  
<link rel="stylesheet" href="../css/admin.css">
<title>Doctors</title>

<style>
/* === Animations === */
.popup, .sub-table { animation: transitionIn-Y-bottom 0.5s; }

/* === Purple Theme === */
:root { --primary-color: #8e44ad; --primary-hover: #732d91; }

/* Buttons */
.btn-primary, .btn-primary-soft, .login-btn.btn-primary, .login-btn.btn-primary-soft { 
    background-color: var(--primary-color) !important; 
    border: none !important; 
    color: #fff !important; 
}
.btn-primary:hover { background-color: var(--primary-hover) !important; }

/* Hamburger Menu */
.hamburger { display: none; cursor: pointer; position: fixed; top: 15px; left: 15px; z-index:1001;
    background: var(--primary-color); border: none; color: white; padding: 10px 12px; border-radius: 6px; font-size:20px;
}
.hamburger:hover { background: var(--primary-hover); }

/* Sidebar */
.menu { transition: transform 0.3s ease-in-out; }
.menu.active { transform: translateX(0); }

/* Overlay & Popups */
.overlay { position: fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.6); z-index:2000;
    display:flex; align-items:center; justify-content:center;
}
.popup { background:#fff; border-radius:12px; padding:25px; width:50%; max-height:90%; overflow-y:auto; position:relative; }
.popup .close { position:absolute; top:10px; right:20px; text-decoration:none; font-size:28px; color:var(--primary-color);}
.popup h2 { color: var(--primary-color); }

/* Scrollable tables */
.scroll { overflow-x: auto; }

/* === Responsive Mobile === */
@media screen and (max-width:768px) {
    .hamburger { display:block; }
    .menu { position: fixed; top:0; left:0; width:220px; height:100%; background:white; transform:translateX(-100%);
        z-index:1000; box-shadow:2px 0 10px rgba(0,0,0,0.1); }
    .dash-body { margin-left:0 !important; padding:15px; }

    /* Popups fullscreen on mobile */
    .popup { width:95%; height:95%; padding:15px; border-radius:10px; overflow-y:auto; }
    .popup .close { font-size:30px; top:15px; right:15px; }

    /* Tables to cards */
    .sub-table, .sub-table tbody, .sub-table tr, .sub-table td, .sub-table th { display:block; width:100% !important; }
    .sub-table thead { display:none; }
    .sub-table tr { background:#f9f9f9; margin-bottom:15px; border-radius:10px; padding:12px; box-shadow:0 2px 6px rgba(0,0,0,0.1); }
    .sub-table td { padding:8px 0; border:none; position:relative; }
    .sub-table td::before { content: attr(data-label); font-weight:600; color:#555; display:block; margin-bottom:5px; }
    td .btn { width:100%; margin-top:8px; }
}
</style>
</head>

<body>
<?php
session_start();
if(isset($_SESSION["user"])){
    if(($_SESSION["user"])=="" or $_SESSION['usertype']!='p'){
        header("location: ../login.php");
    }else{
        $useremail=$_SESSION["user"];
    }
}else{
    header("location: ../login.php");
}

include("../connection.php");
$userrow = $database->query("select * from patient where pemail='$useremail'");
$userfetch=$userrow->fetch_assoc();
$userid= $userfetch["pid"];
$username=$userfetch["pname"];
?>

<!-- Hamburger for Mobile -->
<button class="hamburger" onclick="toggleMenu()">☰</button>

<div class="container">
    <div class="menu" id="sidebar">
        <table class="menu-container" border="0">
            <tr>
                <td style="padding:10px" colspan="2">
                    <table border="0" class="profile-container">
                        <tr>
                            <td width="30%" style="padding-left:20px">
                                <img src="../img/user.png" alt="" width="100%" style="border-radius:50%">
                            </td>
                            <td style="padding:0;margin:0;">
                                <p class="profile-title"><?php echo substr($username,0,13) ?>..</p>
                                <p class="profile-subtitle"><?php echo substr($useremail,0,22) ?></p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <a href="../logout.php"><input type="button" value="Log out" class="logout-btn btn-primary btn"></a>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-home"><a href="index.php" class="non-style-link-menu"><p class="menu-text">Home</p></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-doctor menu-active"><a href="doctors.php" class="non-style-link-menu"><p class="menu-text">All Doctors</p></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-session"><a href="schedule.php" class="non-style-link-menu"><p class="menu-text">Scheduled Sessions</p></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-appoinment"><a href="appointment.php" class="non-style-link-menu"><p class="menu-text">My Bookings</p></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-settings"><a href="settings.php" class="non-style-link-menu"><p class="menu-text">Settings</p></a></td></tr>
        </table>
    </div>

    <div class="dash-body">
        <table border="0" width="100%" style="border-spacing:0;margin-top:25px;">
            <tr>
                <td>
                    <form action="" method="post" class="header-search">
                        <input type="search" name="search" class="input-text header-searchbar" placeholder="Search Doctor name or Email" list="doctors">&nbsp;&nbsp;
                        <?php
                        echo '<datalist id="doctors">';
                        $list11 = $database->query("select docname,docemail from doctor;");
                        for ($y=0;$y<$list11->num_rows;$y++){
                            $row00=$list11->fetch_assoc();
                            echo "<option value='".$row00["docname"]."'>";
                            echo "<option value='".$row00["docemail"]."'>";
                        }
                        echo '</datalist>';
                        ?>
                        <input type="submit" value="Search" class="login-btn btn-primary btn">
                    </form>
                </td>
                <td width="15%" style="text-align:right;">
                    <p style="font-size:14px;color:#777;">Today's Date</p>
                    <p class="heading-sub12"><?php date_default_timezone_set('Asia/Kolkata'); echo date('Y-m-d'); ?></p>
                </td>
            </tr>

            <?php
            if($_POST){
                $keyword=$_POST["search"];
                $sqlmain= "select * from doctor where docemail='$keyword' or docname='$keyword' or docname like '$keyword%' or docname like '%$keyword' or docname like '%$keyword%'";
            }else{
                $sqlmain= "select * from doctor order by docid desc";
            }
            $result= $database->query($sqlmain);
            ?>

            <tr>
                <td colspan="4">
                    <center>
                        <div class="abc scroll">
                            <table width="93%" class="sub-table scrolldown" border="0">
                                <thead>
                                    <tr><th>Doctor Name</th><th>Email</th><th>Specialties</th><th>Events</th></tr>
                                </thead>
                                <tbody>
                                <?php
                                if($result->num_rows==0){
                                    echo '<tr><td colspan="4"><center><img src="../img/notfound.svg" width="25%"><p>No results found.</p></center></td></tr>';
                                } else {
                                    while($row=$result->fetch_assoc()){
                                        $docid=$row["docid"];
                                        $name=$row["docname"];
                                        $email=$row["docemail"];
                                        $spe=$row["specialties"];
                                        $spcil_res= $database->query("select sname from specialties where id='$spe'");
                                        $spcil_array= $spcil_res->fetch_assoc();
                                        $spcil_name=$spcil_array["sname"];
                                        echo '<tr>
                                            <td data-label="Doctor Name">'.substr($name,0,30).'</td>
                                            <td data-label="Email">'.substr($email,0,20).'</td>
                                            <td data-label="Specialties">'.substr($spcil_name,0,20).'</td>
                                            <td data-label="Events"><div style="display:flex;justify-content:center;flex-wrap:wrap;">
                                                <a href="?action=view&id='.$docid.'" class="non-style-link"><button class="btn-primary btn">View</button></a>
                                                <a href="?action=session&id='.$docid.'&name='.$name.'" class="non-style-link"><button class="btn-primary btn">Sessions</button></a>
                                            </div></td>
                                        </tr>';
                                    }
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </center>
                </td>
            </tr>
        </table>
    </div>
</div>

<script>
function toggleMenu() {
    document.getElementById('sidebar').classList.toggle('active');
}
</script>

<?php
if($_GET){
    $id=$_GET["id"];
    $action=$_GET["action"];
    if($action=='view'){
        $row=$database->query("select * from doctor where docid='$id'")->fetch_assoc();
        $spcil_name=$database->query("select sname from specialties where id='".$row["specialties"]."'")->fetch_assoc()["sname"];
        echo '<div class="overlay">
            <div class="popup">
                <a class="close" href="doctors.php">&times;</a>
                <h2>Doctor Details</h2>
                <p><b>Name:</b> '.$row["docname"].'</p>
                <p><b>Email:</b> '.$row["docemail"].'</p>
                <p><b>Specialization:</b> '.$spcil_name.'</p>
            </div>
        </div>';
    } elseif($action=='session'){
        $result=$database->query("select * from schedule where docid='$id' order by scheduleid desc");
        echo '<div class="overlay">
            <div class="popup">
                <a class="close" href="doctors.php">&times;</a>
                <h2>Doctor Sessions</h2>
                <div class="scroll">
                <table width="100%" class="sub-table scrolldown" border="0">
                    <thead><tr><th>Session Title</th><th>Date</th><th>Time</th></tr></thead><tbody>';
                    if($result->num_rows==0){
                        echo '<tr><td colspan="3"><center>No sessions available</center></td></tr>';
                    } else {
                        while($row=$result->fetch_assoc()){
                            echo '<tr><td data-label="Session Title">'.$row["title"].'</td>
                                      <td data-label="Date">'.$row["scheduledate"].'</td>
                                      <td data-label="Time">'.$row["scheduletime"].'</td></tr>';
                        }
                    }
        echo '</tbody></table></div></div></div>';
    }
}
?>
</body>
</html>
