<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!-- Responsive viewport for mobile devices -->
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <!-- External CSS files -->
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
        
    <title>Scheduled Sessions</title>

    <style>
        /* ================= Animations ================= */
        /* Apply transition effect for popups and sub-tables */
        .popup, .sub-table { animation: transitionIn-Y-bottom 0.5s; }

        /* ================= Purple Theme ================= */
        :root { 
            --primary-color: #8e44ad;   /* Main purple color */
            --primary-hover: #732d91;   /* Hover effect for buttons */
        }

        /* Button styles */
        .btn-primary, .btn-primary-soft, .login-btn.btn-primary, .login-btn.btn-primary-soft {
            background-color: var(--primary-color) !important;
            border: none !important;
            color: #fff !important;
        }
        .btn-primary:hover { background-color: var(--primary-hover) !important; }

        /* ================= Hamburger Menu ================= */
        .hamburger {
            display: none; /* hidden on desktop */
            cursor: pointer;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: var(--primary-color);
            border: none;
            color: white;
            padding: 10px 12px;
            border-radius: 6px;
            font-size: 20px;
        }
        .hamburger:hover { background: var(--primary-hover); }

        /* ================= Sidebar for mobile ================= */
        .menu { 
            transition: transform 0.3s ease-in-out; 
        }
        .menu.active { transform: translateX(0); } /* show menu when active */

        @media screen and (max-width: 768px) {
            /* Sidebar styles for small screens */
            .menu {
                position: fixed;
                top: 0;
                left: 0;
                width: 220px;
                height: 100%;
                background-color: white;
                transform: translateX(-100%); /* hide by default */
                z-index: 1000;
                box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            }
            .hamburger { display: block; } /* show hamburger on mobile */
            .dash-body { margin-left: 0 !important; padding: 15px; }
        }

        /* ================= Popup overlay ================= */
        .overlay {
            position: fixed; top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.6); /* semi-transparent background */
            z-index: 2000;
            display: flex; align-items: center; justify-content: center;
        }
        .popup {
            background: #fff;
            border-radius: 12px;
            padding: 25px;
            width: 50%;
            max-height: 90%;
            overflow-y: auto; /* scroll if content is too tall */
            position: relative;
        }
        .popup .close {
            position: absolute; top: 10px; right: 20px;
            text-decoration: none; font-size: 28px; color: var(--primary-color);
        }
        .popup h2 { color: var(--primary-color); }

        @media screen and (max-width: 768px) {
            /* Popup adjustments for mobile */
            .popup { width: 95%; height: 95%; border-radius: 10px; padding: 15px; overflow-y: auto; }
            .popup .close { font-size: 30px; top: 15px; right: 15px; }
        }

        /* ================= Scrollable table/cards ================= */
        .scroll { overflow-x: auto; }
    </style>
</head>
<body>

<?php
session_start();

/* ================= User Authentication ================= */
if(isset($_SESSION["user"])){
    if(($_SESSION["user"])=="" or $_SESSION['usertype']!='p'){ // Check if user is patient
        header("location: ../login.php");
    }else{
        $useremail=$_SESSION["user"]; // store logged in user's email
    }
}else{
    header("location: ../login.php");
}

include("../connection.php"); // database connection

/* ================= Get User Info ================= */
$stmt = $database->prepare("SELECT * FROM patient WHERE pemail=?");
$stmt->bind_param("s",$useremail);
$stmt->execute();
$userresult = $stmt->get_result();
$userfetch = $userresult->fetch_assoc();
$userid = $userfetch["pid"];        // Patient ID
$username = $userfetch["pname"];    // Patient Name

/* ================= Get Current Date ================= */
date_default_timezone_set('Asia/Kolkata'); // set timezone
$today = date('Y-m-d');

/* ================= Prepare Sessions SQL ================= */
$sqlmain = "SELECT * FROM schedule 
            INNER JOIN doctor ON schedule.docid=doctor.docid 
            WHERE schedule.scheduledate>='$today' 
            ORDER BY schedule.scheduledate ASC";

/* ================= Handle Search ================= */
$searchType = "All";
$searchKey = "";
if($_POST && !empty($_POST["search"])) {
    $keyword = $_POST["search"];
    $searchKey = $keyword;
    $searchType = "Search Result: ";
    $sqlmain = "SELECT * FROM schedule 
                INNER JOIN doctor ON schedule.docid=doctor.docid 
                WHERE schedule.scheduledate>='$today' 
                AND (doctor.docname LIKE '%$keyword%' 
                     OR schedule.title LIKE '%$keyword%' 
                     OR schedule.scheduledate LIKE '%$keyword%') 
                ORDER BY schedule.scheduledate ASC";
}

/* ================= Execute Query ================= */
$result = $database->query($sqlmain);
?>

<!-- ================= Hamburger Menu Button ================= -->
<button class="hamburger" onclick="toggleMenu()">☰</button>

<div class="container">
    <!-- ================= Sidebar Menu ================= -->
    <div class="menu" id="sidebar">
        <table class="menu-container" border="0">
            <tr>
                <td colspan="2" style="padding:10px">
                    <!-- Profile Section -->
                    <table class="profile-container" border="0">
                        <tr>
                            <td width="30%" style="padding-left:20px">
                                <img src="../img/user.png" alt="" width="100%" style="border-radius:50%">
                            </td>
                            <td style="padding:0;margin:0">
                                <p ></p></p>
                                <p class="profile-subtitle"><?php echo substr($useremail,0,22); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <a href="../logout.php"><input type="button" value="Log out" class="logout-btn btn-primary btn"></a>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>

            <!-- ================= Menu Links ================= -->
            <tr class="menu-row"><td class="menu-btn menu-icon-home"><a href="index.php" class="non-style-link-menu"><div><p class="menu-text">Home</p></div></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-doctor"><a href="doctors.php" class="non-style-link-menu"><div><p class="menu-text">All Doctors</p></div></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-session menu-active menu-icon-session-active"><a href="schedule.php" class="non-style-link-menu non-style-link-menu-active"><div><p class="menu-text">Scheduled Sessions</p></div></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-appoinment"><a href="appointment.php" class="non-style-link-menu"><div><p class="menu-text">My Bookings</p></div></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-settings"><a href="settings.php" class="non-style-link-menu"><div><p class="menu-text">Settings</p></div></a></td></tr>
        </table>
    </div>

    <!-- ================= Dashboard Body ================= -->
    <div class="dash-body">
        <table border="0" width="100%" style="border-spacing:0;margin-top:25px">
            <tr>
                <!-- Back Button -->
               
                
                <!-- Search Form -->
                <td>
                    <form action="" method="post" class="header-search">
                        <input type="search" name="search" class="input-text header-searchbar" placeholder="Search Doctor, Title, or Date" list="searchlist" value="<?php echo $searchKey; ?>">&nbsp;&nbsp;
                        <?php
                        // Create datalist for autocomplete suggestions
                        echo '<datalist id="searchlist">';
                        $listDoctors = $database->query("SELECT DISTINCT docname FROM doctor;");
                        $listTitles = $database->query("SELECT DISTINCT title FROM schedule;");
                        while($row=$listDoctors->fetch_assoc()){ echo "<option value='{$row['docname']}'><br/>"; }
                        while($row=$listTitles->fetch_assoc()){ echo "<option value='{$row['title']}'><br/>"; }
                        echo '</datalist>';
                        ?>
                        <input type="submit" value="Search" class="login-btn btn-primary btn">
                    </form>
                </td>

                <!-- Today's Date Display -->
                <td width="15%">
                    <p style="font-size:14px;color:#777;text-align:right;">Today's Date</p>
                    <p class="heading-sub12"><?php echo $today; ?></p>
                </td>

                <!-- Calendar Icon -->
                <td width="10%"><button class="btn-label"><img src="../img/calendar.svg" width="100%"></button></td>
            </tr>

            <!-- ================= Heading & Search Result ================= -->
            <tr>
                <td colspan="4" style="padding-top:10px;">
                    <p class="heading-main12" style="margin-left:45px;font-size:18px;"><?php echo $searchType." Sessions (".$result->num_rows.")"; ?></p>
                    <?php if($searchKey!=""){ echo '<p class="heading-main12" style="margin-left:45px;font-size:22px;">"'.$searchKey.'"</p>'; } ?>
                </td>
            </tr>

            <!-- ================= Scheduled Sessions Table ================= -->
            <tr>
                <td colspan="4">
                    <center>
                        <div class="abc scroll">
                            <table width="100%" class="sub-table scrolldown" border="0" style="padding:50px;border:none">
                                <tbody>
                                <?php
                                if($result->num_rows==0){
                                    // No sessions found
                                    echo '<tr><td colspan="4"><center><img src="../img/notfound.svg" width="25%"><br><p>No sessions found!</p><a href="schedule.php"><button class="login-btn btn-primary btn">Show All Sessions</button></a></center></td></tr>';
                                } else {
                                    // Display sessions in 3 columns
                                    $count=0;
                                    while($row=$result->fetch_assoc()){
                                        if($count%3==0) echo "<tr>";
                                        echo '<td style="width:33%"><div class="dashboard-items search-items">
                                                <div style="width:100%">
                                                    <div class="h1-search">'.substr($row["title"],0,21).'</div><br>
                                                    <div class="h3-search">'.substr($row["docname"],0,30).'</div>
                                                    <div class="h4-search">'.$row["scheduledate"].'<br>Starts: <b>@'.substr($row["scheduletime"],0,5).'</b></div><br>
                                                    <a href="booking.php?id='.$row["scheduleid"].'"><button class="login-btn btn-primary btn" style="width:100%">Book Now</button></a>
                                                </div>
                                            </div></td>';
                                        $count++;
                                        if($count%3==0) echo "</tr>";
                                    }
                                    if($count%3!=0) echo "</tr>"; // Close the last row if incomplete
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </center>
                </td>
            </tr>
        </table>
    </div>
</div>

<!-- ================= Toggle Sidebar Script ================= -->
<script>
function toggleMenu(){
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('active'); // show/hide sidebar
}
</script>

</body>
</html>
