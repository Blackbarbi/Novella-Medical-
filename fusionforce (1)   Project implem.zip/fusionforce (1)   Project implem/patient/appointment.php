<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../css/animations.css">  
    <link rel="stylesheet" href="../css/main.css">  
    <link rel="stylesheet" href="../css/admin.css">
        
    <title>Appointments</title>
    <style>
        /* === Animations === */
        .popup, .sub-table { animation: transitionIn-Y-bottom 0.5s; }

        /* === Purple Theme === */
        :root { --primary-color: #8e44ad; --primary-hover: #732d91; }
        .btn-primary, .btn-primary-soft, .login-btn.btn-primary, .login-btn.btn-primary-soft {
            background-color: var(--primary-color) !important;
            border: none !important;
            color: #fff !important;
        }
        .btn-primary:hover { background-color: var(--primary-hover) !important; }

        /* === Hamburger Menu === */
        .hamburger {
            display: none;
            cursor: pointer;
            position: fixed;
            top: 15px;
            left: 15px;
            z-index: 1001;
            background: var(--primary-color);
            border: none;
            color: white;
            padding: 10px 12px;
            border-radius: 6px;
            font-size: 20px;
        }
        .hamburger:hover { background: var(--primary-hover); }

        /* === Sidebar for mobile === */
        .menu { transition: transform 0.3s ease-in-out; }
        .menu.active { transform: translateX(0); }

        @media screen and (max-width: 768px) {
            .menu {
                position: fixed;
                top: 0;
                left: 0;
                width: 220px;
                height: 100%;
                background-color: white;
                transform: translateX(-100%);
                z-index: 1000;
                box-shadow: 2px 0 10px rgba(0,0,0,0.1);
            }
            .hamburger { display: block; }
            .dash-body { margin-left: 0 !important; padding: 15px; }
        }

        /* === Popup overlay === */
        .overlay {
            position: fixed; top: 0; left: 0;
            width: 100%; height: 100%;
            background: rgba(0,0,0,0.6);
            z-index: 2000;
            display: flex; align-items: center; justify-content: center;
        }
        .popup {
            background: #fff;
            border-radius: 12px;
            padding: 25px;
            width: 50%;
            max-height: 90%;
            overflow-y: auto;
            position: relative;
        }
        .popup .close {
            position: absolute; top: 10px; right: 20px;
            text-decoration: none; font-size: 28px; color: var(--primary-color);
        }
        .popup h2 { color: var(--primary-color); }
        @media screen and (max-width: 768px) {
            .popup { width: 95%; height: 95%; border-radius: 10px; padding: 15px; overflow-y: auto; }
            .popup .close { font-size: 30px; top: 15px; right: 15px; }
        }

        /* === Scrollable table/cards === */
        .scroll { overflow-x: auto; }

        /* === Cards layout for smaller screens === */
        @media screen and (max-width: 480px) {
            .dashboard-items { width: 95% !important; margin-bottom: 15px; }
            .sub-table td { width: 100% !important; display: block; }
        }
    </style>
</head>
<body>

<?php
session_start();
if(isset($_SESSION["user"])){
    if($_SESSION["user"]=="" || $_SESSION['usertype']!='p'){
        header("location: ../login.php");
    } else {
        $useremail=$_SESSION["user"];
    }
} else { header("location: ../login.php"); }

include("../connection.php");

// Get user info
$stmt = $database->prepare("SELECT * FROM patient WHERE pemail=?");
$stmt->bind_param("s",$useremail);
$stmt->execute();
$userrow = $stmt->get_result();
$userfetch=$userrow->fetch_assoc();
$userid= $userfetch["pid"];
$username=$userfetch["pname"];

// Get appointments
$sqlmain = "SELECT appointment.appoid, schedule.scheduleid, schedule.title, doctor.docname, patient.pname, schedule.scheduledate, schedule.scheduletime, appointment.apponum, appointment.appodate 
            FROM schedule 
            INNER JOIN appointment ON schedule.scheduleid=appointment.scheduleid 
            INNER JOIN patient ON patient.pid=appointment.pid 
            INNER JOIN doctor ON schedule.docid=doctor.docid  
            WHERE patient.pid=$userid";

if($_POST && !empty($_POST["sheduledate"])) {
    $sheduledate=$_POST["sheduledate"];
    $sqlmain.=" AND schedule.scheduledate='$sheduledate' ";
}

$sqlmain.=" ORDER BY appointment.appodate ASC";
$result= $database->query($sqlmain);
?>

<!-- Hamburger -->
<button class="hamburger" onclick="toggleMenu()">☰</button>

<div class="container">
    <!-- Sidebar -->
    <div class="menu" id="sidebar">
        <table class="menu-container" border="0">
            <tr>
                <td colspan="2" style="padding:10px">
                    <table class="profile-container" border="0">
                        <tr>
                            <td width="30%" style="padding-left:20px">
                                <img src="../img/user.png" alt="" width="100%" style="border-radius:50%">
                            </td>
                            <td style="padding:0;margin:0">
                                <p ></p>
                                <p class="profile-subtitle"><?php echo substr($useremail,0,22); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <a href="../logout.php"><input type="button" value="Log out" class="logout-btn btn-primary btn"></a>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-home"><a href="index.php" class="non-style-link-menu"><div><p class="menu-text">Home</p></div></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-doctor"><a href="doctors.php" class="non-style-link-menu"><div><p class="menu-text">All Doctors</p></div></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-session"><a href="schedule.php" class="non-style-link-menu"><div><p class="menu-text">Scheduled Sessions</p></div></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-appoinment menu-active menu-icon-appoinment-active"><a href="appointment.php" class="non-style-link-menu non-style-link-menu-active"><div><p class="menu-text">My Bookings</p></div></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-settings"><a href="settings.php" class="non-style-link-menu"><div><p class="menu-text">Settings</p></div></a></td></tr>
        </table>
    </div>

    <!-- Dashboard -->
    <div class="dash-body">
        <table border="0" width="100%" style="border-spacing:0;margin-top:25px">
            <tr>
                
                <td><p style="font-size:23px;padding-left:12px;font-weight:600;">My Bookings History</p></td>
                <td width="15%" style="text-align:right">
                    <p style="font-size:14px;color:#777;margin:0">Today's Date</p>
                    <p class="heading-sub12"><?php echo date('Y-m-d'); ?></p>
                </td>
                <td width="10%"><button class="btn-label"><img src="../img/calendar.svg" width="100%"></button></td>
            </tr>

            <!-- Filter by date -->
            <tr>
                <td colspan="4">
                    <center>
                        <form action="" method="post" style="display:flex;align-items:center;justify-content:center;margin-top:10px;">
                            <label>Date:&nbsp;</label>
                            <input type="date" name="sheduledate" class="input-text filter-container-items" style="margin-right:10px;">
                            <input type="submit" value="Filter" class="btn-primary-soft btn">
                        </form>
                    </center>
                </td>
            </tr>

            <!-- Appointment Cards -->
            <tr>
                <td colspan="4">
                    <center>
                        <div class="abc scroll">
                            <table class="sub-table scrolldown" border="0" style="border:none;width:95%">
                                <tbody>
                                <?php
                                if($result->num_rows==0){
                                    echo '<tr><td colspan="3"><center><img src="../img/notfound.svg" width="25%"><p>No Appointments Found!</p><a href="appointment.php"><button class="login-btn btn-primary btn">Show All Appointments</button></a></center></td></tr>';
                                } else {
                                    $count=0;
                                    while($row=$result->fetch_assoc()){
                                        if($count%3==0) echo "<tr>";
                                        echo '<td style="width:33%"><div class="dashboard-items search-items">
                                                <div>
                                                    <div class="h3-search">Booking Date: '.$row["appodate"].'<br>Reference: OC-000-'.$row["appoid"].'</div>
                                                    <div class="h1-search">'.substr($row["title"],0,21).'</div>
                                                    <div class="h3-search">Appointment Number: 0'.$row["apponum"].'</div>
                                                    <div class="h3-search">'.substr($row["docname"],0,30).'</div>
                                                    <div class="h4-search">Scheduled Date: '.$row["scheduledate"].'<br>Starts: <b>@'.substr($row["scheduletime"],0,5).'</b></div>
                                                    <br>
                                                    <a href="?action=drop&id='.$row["appoid"].'"><button class="login-btn btn-primary-soft btn" style="width:100%">Cancel Booking</button></a>
                                                </div>
                                            </div></td>';
                                        $count++;
                                        if($count%3==0) echo "</tr>";
                                    }
                                    if($count%3!=0) echo "</tr>";
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </center>
                </td>
            </tr>
        </table>
    </div>
</div>

<script>
// Hamburger toggle
function toggleMenu(){
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('active');
}
</script>
</body>
</html>
