<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<!-- CSS -->
<link rel="stylesheet" href="../css/animations.css">  
<link rel="stylesheet" href="../css/main.css">  
<link rel="stylesheet" href="../css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<title>Dashboard</title>

<style>
/* ---------- Animations ---------- */
.dashbord-tables,.doctor-header{ animation: transitionIn-Y-over 0.5s; }
.filter-container,.sub-table{ animation: transitionIn-Y-bottom 0.5s; }

/* ---------- Colors & Sidebar ---------- */
:root {
  --main-color: #6a0dad; /* Purple main color */
  --hover-color: #5b0aa3;
}

.menu { 
    background-color: var(--main-color);
    color: #fff;
    min-height: 100vh;
    width: 250px;
    position: relative;
    transition: transform 0.3s ease;
}
.menu.active { transform: translateX(0); }
.menu-text { color: #fff; }

/* ---------- Layout ---------- */
.container{ display: flex; min-height: 100vh; overflow-x: hidden; }
.dash-body{ flex: 1; padding: 20px; background: #f9f9f9; overflow-y: auto; }
.nav-bar{ display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; }

/* ---------- Dashboard Cards ---------- */
.dashboard-items{
    background: #fff;
    border-radius: 12px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 25px;
    box-shadow: 0px 2px 5px rgba(0,0,0,0.1);
    transition: transform 0.3s;
}
.dashboard-items:hover{ transform: translateY(-3px); }
.h1-dashboard{ font-size: 28px; font-weight: 700; color: var(--main-color); }
.h3-dashboard{ font-size: 15px; font-weight: 500; color: #333; }
.dashboard-icons{ width: 50px; height: 50px; background-size: cover; }

/* ---------- Menu Toggle (Mobile) ---------- */
.menu-toggle{
    display: none;
    background: var(--main-color);
    border: none;
    color: white;
    font-size: 22px;
    padding: 10px 15px;
    border-radius: 8px;
    cursor: pointer;
    transition: background 0.3s;
}
.menu-toggle:hover{ background: var(--hover-color); }

/* ---------- Responsive ---------- */
@media screen and (max-width:1024px){
    .container{ flex-direction: column; }
    .menu{ width: 100%; min-height: auto; transform: translateY(0); }
    .dash-body{ padding: 15px; }
    .dashboard-items{ flex-direction: column; text-align: center; }
    .sub-table th, .sub-table td{ font-size: 13px; padding: 8px; }
}

@media screen and (max-width:768px){
    .menu{
        position: fixed;
        top: 0;
        left: 0;
        width: 250px;
        height: 100%;
        transform: translateX(-100%);
        z-index: 10;
        box-shadow: 2px 0 10px rgba(0,0,0,0.3);
    }
    .menu.active{ transform: translateX(0); }
    .menu-toggle{ display: block; margin-bottom: 15px; }
    .dashboard-items{ width: 100%; }
    .abc.scroll{ max-height: 200px; overflow-y:auto; }
}

@media screen and (max-width:480px){
    .h1-dashboard{ font-size: 22px; }
    .h3-dashboard{ font-size: 13px; }
    .dashboard-items{ padding: 15px; flex-direction: column; gap:10px; }
    .dashboard-icons{ width: 40px; height: 40px; margin-top:5px; }
    h1,h3,p{ font-size: 14px; }
    .sub-table th, .sub-table td{ font-size: 12px; padding: 6px; }
    .filter-container{ width: 100%; padding: 10px; }
    form{ flex-direction: column; gap: 10px; }
}
</style>
</head>
<body>

<?php
session_start();
if(isset($_SESSION["user"])){
    if(($_SESSION["user"])=="" or $_SESSION['usertype']!='d'){
        header("location: ../login.php");
    }else{
        $useremail=$_SESSION["user"];
    }
}else{
    header("location: ../login.php");
}
include("../connection.php");

$userrow = $database->query("select * from doctor where docemail='$useremail'");
$userfetch=$userrow->fetch_assoc();
$userid= $userfetch["docid"];
$username=$userfetch["docname"];
$today = date('Y-m-d');

$patientrow = $database->query("select * from patient;");
$doctorrow = $database->query("select * from doctor;");
$appointmentrow = $database->query("select * from appointment where appodate>='$today';");
$schedulerow = $database->query("select * from schedule where scheduledate='$today';");
?>

<div class="container">
    <!-- Sidebar Toggle (Mobile) -->
    <button class="menu-toggle" id="menuToggle"><i class="fa-solid fa-bars"></i></button>

    <!-- Sidebar -->
    <div class="menu" id="sidebar">
        <table class="menu-container" border="0">
            <tr>
                <td style="padding:10px" colspan="2">
                    <table border="0" class="profile-container">
                        <tr>
                            <td width="30%" style="padding-left:20px">
                                <img src="../img/user.png" alt="" width="100%" style="border-radius:50%">
                            </td>
                            <td style="padding:0;margin:0;">
                                <p class="profile-title"><?php echo strlen($username)>13 ? substr($username,0,13).'..' : $username; ?></p>
                                <p class="profile-subtitle"><?php echo substr($useremail,0,22); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <a href="../logout.php"><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>

            <tr class="menu-row"><td class="menu-btn menu-active"><a href="index.php" class="non-style-link-menu"><p class="menu-text"><i class="fa-solid fa-house menu-icon"></i> Dashboard</p></a></td></tr>
            <tr class="menu-row"><td class="menu-btn"><a href="appointment.php" class="non-style-link-menu"><p class="menu-text"><i class="fa-solid fa-book menu-icon"></i> My Appointments</p></a></td></tr>
            <tr class="menu-row"><td class="menu-btn"><a href="schedule.php" class="non-style-link-menu"><p class="menu-text"><i class="fa-solid fa-calendar-days menu-icon"></i> My Sessions</p></a></td></tr>
            <tr class="menu-row"><td class="menu-btn"><a href="patient.php" class="non-style-link-menu"><p class="menu-text"><i class="fa-solid fa-user menu-icon"></i> My Patients</p></a></td></tr>
            <tr class="menu-row"><td class="menu-btn"><a href="settings.php" class="non-style-link-menu"><p class="menu-text"><i class="fa-solid fa-gear menu-icon"></i> Settings</p></a></td></tr>
        </table>
    </div>

    <!-- Dashboard Body -->
    <div class="dash-body">
        <div class="nav-bar">
            <p style="font-size:23px;font-weight:600;">Dashboard</p>
            <div style="text-align:right;">
                <p style="font-size:14px;color:#777;">Today's Date</p>
                <p class="heading-sub12"><?php echo $today; ?></p>
            </div>
        </div>

        <!-- Welcome Section -->
        <div class="filter-container doctor-header" style="border:none;width:100%;margin-top:20px;">
            <h3>Welcome!</h3>
            <h1><?php echo $username; ?>.</h1>
            <p>Thanks for joining with us. You can view your daily schedule and patient appointments.</p>
            <a href="appointment.php"><button class="btn-primary btn">View My Appointments</button></a>
        </div>

        <!-- Status -->
        <div style="margin-top:30px;">
            <p style="font-size:20px;font-weight:600;">Status</p>
            <div style="display:flex;flex-wrap:wrap;gap:20px;">
                <div class="dashboard-items"><div><div class="h1-dashboard"><?php echo $doctorrow->num_rows; ?></div><div class="h3-dashboard">All Doctors</div></div><div class="dashboard-icons" style="background-image:url('../img/icons/doctors-hover.svg');"></div></div>
                <div class="dashboard-items"><div><div class="h1-dashboard"><?php echo $patientrow->num_rows; ?></div><div class="h3-dashboard">All Patients</div></div><div class="dashboard-icons" style="background-image:url('../img/icons/patients-hover.svg');"></div></div>
                <div class="dashboard-items"><div><div class="h1-dashboard"><?php echo $appointmentrow->num_rows; ?></div><div class="h3-dashboard">New Booking</div></div><div class="dashboard-icons" style="background-image:url('../img/icons/book-hover.svg');"></div></div>
                <div class="dashboard-items"><div><div class="h1-dashboard"><?php echo $schedulerow->num_rows; ?></div><div class="h3-dashboard">Today Sessions</div></div><div class="dashboard-icons" style="background-image:url('../img/icons/session-iceblue.svg');"></div></div>
            </div>
        </div>

        <!-- Upcoming Sessions -->
        <div style="margin-top:40px;">
            <p style="font-size:20px;font-weight:600;">Your Upcoming Sessions</p>
            <div class="abc scroll" style="max-height:250px;overflow:auto;">
                <table width="100%" class="sub-table" border="0">
                    <thead>
                        <tr><th>Session Title</th><th>Scheduled Date</th><th>Time</th></tr>
                    </thead>
                    <tbody>
                        <?php
                        $nextweek=date("Y-m-d",strtotime("+1 week"));
                        $sqlmain= "select * from schedule where docid=$userid and scheduledate>='$today' and scheduledate<='$nextweek' order by scheduledate asc"; 
                        $result= $database->query($sqlmain);
                        if($result->num_rows==0){
                            echo '<tr><td colspan="3" style="text-align:center;padding:30px;">
                            <img src="../img/notfound.svg" width="25%"><br>
                            <p style="font-size:16px;color:#333">Nothing to show here!</p>
                            <a href="schedule.php"><button class="login-btn btn-primary-soft btn" style="margin-top:10px;">&nbsp; Show All Sessions &nbsp;</button></a>
                            </td></tr>';
                        } else{
                            while($row=$result->fetch_assoc()){
                                echo '<tr>
                                    <td>'.substr($row["title"],0,30).'</td>
                                    <td>'.$row["scheduledate"].'</td>
                                    <td>'.$row["scheduletime"].'</td>
                                </tr>';
                            }
                        }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
// Toggle sidebar visibility
const menuToggle = document.getElementById("menuToggle");
const sidebar = document.getElementById("sidebar");
menuToggle.addEventListener("click", () => {
    sidebar.classList.toggle("active");
});
</script>

</body>
</html>
