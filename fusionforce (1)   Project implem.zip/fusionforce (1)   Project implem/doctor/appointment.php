<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="../css/animations.css">  
<link rel="stylesheet" href="../css/main.css">  
<link rel="stylesheet" href="../css/admin.css">

<title>Appointments</title>
<style>
    /* === Animations === */
    .popup, .sub-table { animation: transitionIn-Y-bottom 0.5s; }

    /* === Purple Theme === */
    :root { --primary-color: #8e44ad; --primary-hover: #732d91; }
    .btn-primary, .btn-primary-soft, .login-btn.btn-primary, .login-btn.btn-primary-soft {
        background-color: var(--primary-color) !important;
        border: none !important;
        color: #fff !important;
    }
    .btn-primary:hover { background-color: var(--primary-hover) !important; }

    /* === Hamburger Menu === */
    .hamburger {
        display: none;
        cursor: pointer;
        position: fixed;
        top: 15px;
        left: 15px;
        z-index: 1001;
        background: var(--primary-color);
        border: none;
        color: white;
        padding: 10px 12px;
        border-radius: 6px;
        font-size: 20px;
    }
    .hamburger:hover { background: var(--primary-hover); }

    /* === Sidebar for mobile === */
    .menu { transition: transform 0.3s ease-in-out; }
    .menu.active { transform: translateX(0); }

    @media screen and (max-width: 768px) {
        .menu {
            position: fixed;
            top: 0;
            left: 0;
            width: 220px;
            height: 100%;
            background-color: white;
            transform: translateX(-100%);
            z-index: 1000;
            box-shadow: 2px 0 10px rgba(0,0,0,0.1);
        }
        .hamburger { display: block; }
        .dash-body { margin-left: 0 !important; padding: 15px; }
    }

    /* === Popup overlay === */
    .overlay {
        position: fixed; top: 0; left: 0;
        width: 100%; height: 100%;
        background: rgba(0,0,0,0.6);
        z-index: 2000;
        display: flex; align-items: center; justify-content: center;
    }
    .popup {
        background: #fff;
        border-radius: 12px;
        padding: 25px;
        width: 50%;
        max-height: 90%;
        overflow-y: auto;
        position: relative;
    }
    .popup .close {
        position: absolute; top: 10px; right: 20px;
        text-decoration: none; font-size: 28px; color: var(--primary-color);
    }
    .popup h2 { color: var(--primary-color); }
    @media screen and (max-width: 768px) {
        .popup { width: 95%; height: 95%; border-radius: 10px; padding: 15px; overflow-y: auto; }
        .popup .close { font-size: 30px; top: 15px; right: 15px; }
    }

    /* === Scrollable table/cards === */
    .scroll { overflow-x: auto; }

    /* === Card layout for small screens === */
    @media screen and (max-width: 480px) {
        .sub-table, .sub-table tbody, .sub-table tr, .sub-table td, .sub-table th {
            display: block;
            width: 100% !important;
        }
        .sub-table thead { display: none; }
        .sub-table tr {
            background: #f9f9f9;
            margin-bottom: 15px;
            border-radius: 8px;
            padding: 10px;
            box-shadow: 0 1px 4px rgba(0,0,0,0.1);
        }
        .sub-table td {
            padding: 8px 10px;
            border: none;
            position: relative;
        }
        .sub-table td::before {
            content: attr(data-label);
            font-weight: 600;
            color: #555;
            display: inline-block;
            width: 120px;
        }
        td .btn { width: 100%; margin-top: 5px; }
    }
</style>
</head>
<body>
<?php
session_start();
if(isset($_SESSION["user"])){
    if($_SESSION["user"]=="" || $_SESSION['usertype']!='d'){
        header("location: ../login.php");
    } else {
        $useremail=$_SESSION["user"];
    }
} else { header("location: ../login.php"); }

include("../connection.php");

// Get doctor info
$stmt = $database->prepare("SELECT * FROM doctor WHERE docemail=?");
$stmt->bind_param("s",$useremail);
$stmt->execute();
$userrow = $stmt->get_result();
$userfetch=$userrow->fetch_assoc();
$userid= $userfetch["docid"];
$username=$userfetch["docname"];

// Get appointments
$sqlmain = "SELECT appointment.appoid, schedule.scheduleid, schedule.title, patient.pname, schedule.scheduledate, schedule.scheduletime, appointment.apponum, appointment.appodate
            FROM schedule 
            INNER JOIN appointment ON schedule.scheduleid=appointment.scheduleid 
            INNER JOIN patient ON patient.pid=appointment.pid 
            WHERE schedule.docid=$userid";

if($_POST && !empty($_POST["sheduledate"])) {
    $sheduledate=$_POST["sheduledate"];
    $sqlmain.=" AND schedule.scheduledate='$sheduledate' ";
}

$sqlmain.=" ORDER BY appointment.appodate ASC";
$result= $database->query($sqlmain);
?>

<!-- Hamburger -->
<button class="hamburger" onclick="toggleMenu()">☰</button>

<div class="container">
    <!-- Sidebar -->
    <div class="menu" id="sidebar">
        <table class="menu-container" border="0">
            <tr>
                <td colspan="2" style="padding:10px">
                    <table class="profile-container" border="0">
                        <tr>
                           
                            <td style="padding:0;margin:0">
                                <p ></p>
                                <p class="profile-subtitle"><?php echo substr($useremail,0,22); ?></p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <a href="../logout.php"><input type="button" value="Log out" class="logout-btn btn-primary btn"></a>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-dashbord"><a href="index.php" class="non-style-link-menu"><div><p class="menu-text">Dashboard</p></div></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-appoinment menu-active menu-icon-appoinment-active"><a href="appointment.php" class="non-style-link-menu non-style-link-menu-active"><div><p class="menu-text">My Appointments</p></div></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-session"><a href="schedule.php" class="non-style-link-menu"><div><p class="menu-text">My Sessions</p></div></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-patient"><a href="patient.php" class="non-style-link-menu"><div><p class="menu-text">My Patients</p></div></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-settings"><a href="settings.php" class="non-style-link-menu"><div><p class="menu-text">Settings</p></div></a></td></tr>
        </table>
    </div>

    <!-- Dashboard -->
    <div class="dash-body">
        <table border="0" width="100%" style="border-spacing:0;margin-top:25px">
            <tr>
                <td><p style="font-size:23px;padding-left:12px;font-weight:600;">Appointment Manager</p></td>
                <td width="15%" style="text-align:right">
                    <p style="font-size:14px;color:#777;margin:0">Today's Date</p>
                    <p class="heading-sub12"><?php echo date('Y-m-d'); ?></p>
                </td>
                <td width="10%"><button class="btn-label"><img src="../img/calendar.svg" width="100%"></button></td>
            </tr>

            <!-- Filter by date -->
            <tr>
                <td colspan="4">
                    <center>
                        <form action="" method="post" style="display:flex;align-items:center;justify-content:center;margin-top:10px;">
                            <label>Date:&nbsp;</label>
                            <input type="date" name="sheduledate" class="input-text filter-container-items" style="margin-right:10px;">
                            <input type="submit" value="Filter" class="btn-primary-soft btn">
                        </form>
                    </center>
                </td>
            </tr>

            <!-- Appointment Table -->
            <tr>
                <td colspan="4">
                    <center>
                        <div class="abc scroll">
                            <table class="sub-table scrolldown" border="0" style="border:none;width:95%">
                                <thead>
                                    <tr>
                                        <th>Patient Name</th>
                                        <th>Appointment #</th>
                                        <th>Session Title</th>
                                        <th>Session Date & Time</th>
                                        <th>Appointment Date</th>
                                        <th>Events</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                if($result->num_rows==0){
                                    echo '<tr><td colspan="6"><center><img src="../img/notfound.svg" width="25%"><p>No Appointments Found!</p><a href="appointment.php"><button class="login-btn btn-primary btn">Show All Appointments</button></a></center></td></tr>';
                                } else {
                                    while($row=$result->fetch_assoc()){
                                        echo '<tr>
                                            <td data-label="Patient Name">'.substr($row["pname"],0,25).'</td>
                                            <td data-label="Appointment #" style="text-align:center">'.$row["apponum"].'</td>
                                            <td data-label="Session Title">'.substr($row["title"],0,20).'</td>
                                            <td data-label="Session Date & Time" style="text-align:center">'.$row["scheduledate"].' @'.substr($row["scheduletime"],0,5).'</td>
                                            <td data-label="Appointment Date" style="text-align:center">'.$row["appodate"].'</td>
                                            <td data-label="Events">
                                                <div style="display:flex;justify-content: center;">
                                                    <a href="?action=drop&id='.$row["appoid"].'" class="non-style-link">
                                                        <button class="btn-primary-soft btn" style="padding:8px 20px;">Cancel</button>
                                                    </a>
                                                </div>
                                            </td>
                                        </tr>';
                                    }
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </center>
                </td>
            </tr>
        </table>
    </div>
</div>

<script>
// Hamburger toggle
function toggleMenu(){
    const sidebar = document.getElementById('sidebar');
    sidebar.classList.toggle('active');
}
</script>
</body>
</html>
