<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="../css/animations.css">  
<link rel="stylesheet" href="../css/main.css">  
<link rel="stylesheet" href="../css/admin.css">
<title>Patients</title>

<style>
/* === Animations === */
.popup, .sub-table { animation: transitionIn-Y-bottom 0.5s; }

/* === Purple Theme === */
:root { --primary-color: #8e44ad; --primary-hover: #732d91; }
.btn-primary, .btn-primary-soft { background-color: var(--primary-color) !important; border:none; color:white !important; }
.btn-primary:hover, .btn-primary-soft:hover { background-color: var(--primary-hover) !important; }

/* === Scrollable Tables === */
.scroll { overflow-x: auto; }

/* === Popup Overlay === */
.overlay {
    position: fixed; top: 0; left:0;
    width:100%; height:100%;
    background: rgba(0,0,0,0.6);
    z-index:2000;
    display:flex; align-items:center; justify-content:center;
}
.popup {
    background: #fff;
    border-radius:12px;
    padding:25px;
    width:50%;
    max-height:90%;
    overflow-y:auto;
    position: relative;
}
.popup .close {
    position:absolute; top:10px; right:20px;
    text-decoration:none; font-size:28px; color:var(--primary-color);
}

/* === Popup content styling === */
.popup h2 { color: var(--primary-color); margin-bottom:20px; }
.popup table { width:100%; border-collapse: collapse; }
.popup table td { padding:8px 10px; vertical-align:top; }
.popup table td:first-child { font-weight:600; width:30%; color:#555; }

/* === Responsive Popup === */
@media screen and (max-width:768px) {
    .popup { width:95%; height:95%; padding:15px; border-radius:10px; }
    .popup .close { font-size:30px; top:15px; right:15px; }
}

/* === Sub-table for mobile cards === */
@media screen and (max-width:768px) {
    .sub-table, .sub-table tbody, .sub-table tr, .sub-table td, .sub-table th {
        display: block;
        width: 100% !important;
    }
    .sub-table thead { display: none; }
    .sub-table tr {
        background: #f9f9f9;
        margin-bottom: 15px;
        border-radius: 10px;
        padding: 12px;
        box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }
    .sub-table td {
        padding: 8px 0;
        border: none;
        position: relative;
    }
    .sub-table td::before {
        content: attr(data-label);
        font-weight: 600;
        color: #555;
        display: block;
        margin-bottom: 5px;
    }
    td .btn { 
        width: 100%; 
        margin-top: 8px; 
    }
}

/* === Burger Menu === */
.burger-menu {
    display: none;
    position: fixed;
    top: 15px;
    left: 15px;
    z-index: 3000;
    cursor: pointer;
}
.burger-menu .bar {
    width: 25px;
    height: 3px;
    background-color: var(--primary-color);
    margin: 5px 0;
    transition: 0.4s;
}

/* === Sidebar Responsive === */
@media screen and (max-width:768px) {
    .burger-menu { display: block; }
    .menu {
        position: fixed;
        left: -250px;
        top: 0;
        width: 250px;
        height: 100%;
        background: #fff;
        box-shadow: 2px 0 5px rgba(0,0,0,0.1);
        transition: 0.3s;
        z-index: 2500;
        overflow-y: auto;
    }
    .menu.active { left: 0; }
    .dash-body { margin-left: 0 !important; transition: 0.3s; }
}
</style>
</head>
<body>
<?php
session_start();
if(isset($_SESSION["user"])){
    if($_SESSION["user"]=="" || $_SESSION['usertype']!='d'){
        header("location: ../login.php");
    }else{
        $useremail=$_SESSION["user"];
    }
}else{
    header("location: ../login.php");
}

include("../connection.php");
$userrow = $database->query("SELECT * FROM doctor WHERE docemail='$useremail'");
$userfetch=$userrow->fetch_assoc();
$userid= $userfetch["docid"];
$username=$userfetch["docname"];

// Default SQL
$sqlmain= "SELECT * FROM appointment INNER JOIN patient ON patient.pid=appointment.pid INNER JOIN schedule ON schedule.scheduleid=appointment.scheduleid WHERE schedule.docid=$userid";
$selecttype="My";
$current="My patients Only";

if($_POST){
    if(isset($_POST["search"])){
        $keyword=$_POST["search12"];
        $sqlmain= "SELECT * FROM patient WHERE pemail='$keyword' OR pname='$keyword' OR pname LIKE '$keyword%' OR pname LIKE '%$keyword' OR pname LIKE '%$keyword%'";
        $selecttype="My";
    }
    if(isset($_POST["filter"])){
        if($_POST["showonly"]=='all'){
            $sqlmain= "SELECT * FROM patient";
            $selecttype="All";
            $current="All patients";
        }else{
            $sqlmain= "SELECT * FROM appointment INNER JOIN patient ON patient.pid=appointment.pid INNER JOIN schedule ON schedule.scheduleid=appointment.scheduleid WHERE schedule.docid=$userid;";
            $selecttype="My";
            $current="My patients Only";
        }
    }
}
$result= $database->query($sqlmain);
?>

<!-- Burger Menu -->
<div class="burger-menu" onclick="toggleSidebar()">
    <div class="bar"></div>
    <div class="bar"></div>
    <div class="bar"></div>
</div>

<div class="container">
    <!-- Sidebar -->
    <div class="menu">
        <table class="menu-container" border="0">
            <tr>
                <td colspan="2" style="padding:10px;">
                    <table class="profile-container" border="0">
                        <tr>
                            <td width="30%" style="padding-left:20px">
                                <img src="../img/user.png" width="100%" style="border-radius:50%">
                            </td>
                            <td>
                                <p class="profile-title"><?php echo substr($username,0,13) ?>..</p>
                                <p class="profile-subtitle"><?php echo substr($useremail,0,22) ?></p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <a href="../logout.php"><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-dashbord"><a href="index.php" class="non-style-link-menu"><div><p class="menu-text">Dashboard</p></div></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-appoinment"><a href="appointment.php" class="non-style-link-menu"><div><p class="menu-text">My Appointments</p></div></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-session"><a href="schedule.php" class="non-style-link-menu"><div><p class="menu-text">My Sessions</p></div></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-patient menu-active menu-icon-patient-active"><a href="patient.php" class="non-style-link-menu non-style-link-menu-active"><div><p class="menu-text">My Patients</p></div></a></td></tr>
            <tr class="menu-row"><td class="menu-btn menu-icon-settings"><a href="settings.php" class="non-style-link-menu"><div><p class="menu-text">Settings</p></div></a></td></tr>
        </table>
    </div>

    <!-- Main Body -->
    <div class="dash-body">
        <table width="100%" style="border-spacing:0;margin-top:25px;">
            <tr>
                <td width="13%">
                    <a href="patient.php"><button class="login-btn btn-primary-soft btn btn-icon-back" style="padding:11px 0;margin-left:20px;width:125px"></button></a>
                </td>
                <td>
                    <form action="" method="post" class="header-search">
                        <input type="search" name="search12" class="input-text header-searchbar" placeholder="Search Patient name or Email" list="patient">&nbsp;&nbsp;
                        <datalist id="patient">
                        <?php
                        $list11 = $database->query($sqlmain);
                        for ($y=0;$y<$list11->num_rows;$y++){
                            $row00=$list11->fetch_assoc();
                            echo "<option value='".$row00["pname"]."'>";
                            echo "<option value='".$row00["pemail"]."'>";
                        }
                        ?>
                        </datalist>
                        <input type="Submit" value="Search" name="search" class="login-btn btn-primary btn" style="padding:10px 25px;">
                    </form>
                </td>
                <td width="15%" style="text-align:right;">
                    <p style="font-size:14px;color:#777;margin:0;">Today's Date</p>
                    <p class="heading-sub12" style="margin:0;"><?php date_default_timezone_set('Asia/Kolkata'); echo date('Y-m-d'); ?></p>
                </td>
                <td width="10%">
                    <button class="btn-label" style="display:flex;justify-content:center;align-items:center;"><img src="../img/calendar.svg" width="100%"></button>
                </td>
            </tr>

            <tr>
                <td colspan="4" style="padding-top:10px;">
                    <p class="heading-main12" style="margin-left:45px;font-size:18px;color:#313131"><?php echo $selecttype." Patients (".$result->num_rows.")"; ?></p>
                </td>
            </tr>

            <!-- Filter -->
            <tr>
                <td colspan="4">
                    <center>
                        <form action="" method="post" style="display:flex;align-items:center;justify-content:center;margin-bottom:15px;">
                            <label>Show Details About:&nbsp;</label>
                            <select name="showonly" class="box filter-container-items" style="width:150px;height:37px;">
                                <option value="" disabled selected hidden><?php echo $current ?></option>
                                <option value="my">My Patients Only</option>
                                <option value="all">All Patients</option>
                            </select>
                            <input type="submit" name="filter" value=" Filter" class="btn-primary-soft btn" style="margin-left:10px;">
                        </form>
                    </center>
                </td>
            </tr>

            <!-- Patients Table -->
            <tr>
                <td colspan="4">
                    <center>
                        <div class="abc scroll">
                            <table class="sub-table scrolldown" width="93%" border="0">
                                <thead>
                                    <tr>
                                        <th>Name</th>
                                        <th>NIC</th>
                                        <th>Telephone</th>
                                        <th>Email</th>
                                        <th>Date of Birth</th>
                                        <th>Events</th>
                                    </tr>
                                </thead>
                                <tbody>
                                <?php
                                if($result->num_rows==0){
                                    echo '<tr><td colspan="6" style="text-align:center;"><img src="../img/notfound.svg" width="25%"><br><p>No patients found!</p></td></tr>';
                                } else {
                                    while($row=$result->fetch_assoc()){
                                        $pid=$row["pid"];
                                        echo '<tr>
                                            <td data-label="Name">'.substr($row["pname"],0,35).'</td>
                                            <td data-label="NIC">'.substr($row["pnic"],0,12).'</td>
                                            <td data-label="Telephone">'.substr($row["ptel"],0,10).'</td>
                                            <td data-label="Email">'.substr($row["pemail"],0,20).'</td>
                                            <td data-label="DOB">'.substr($row["pdob"],0,10).'</td>
                                            <td data-label="Events" style="text-align:center;">
                                                <a href="?action=view&id='.$pid.'" class="non-style-link"><button class="btn-primary-soft btn">View</button></a>
                                            </td>
                                        </tr>';
                                    }
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </center>
                </td>
            </tr>
        </table>
    </div>
</div>

<?php
// Popup for viewing patient details
if(isset($_GET['action']) && $_GET['action']=='view'){
    $id=$_GET['id'];
    $row=$database->query("SELECT * FROM patient WHERE pid='$id'")->fetch_assoc();
    echo '<div class="overlay">
        <div class="popup">
            <a class="close" href="patient.php">&times;</a>
            <h2>Patient Details</h2>
            <table>
                <tr><td>Patient ID:</td><td>P-'.$row["pid"].'</td></tr>
                <tr><td>Name:</td><td>'.$row["pname"].'</td></tr>
                <tr><td>Email:</td><td>'.$row["pemail"].'</td></tr>
                <tr><td>NIC:</td><td>'.$row["pnic"].'</td></tr>
                <tr><td>Telephone:</td><td>'.$row["ptel"].'</td></tr>
                <tr><td>Address:</td><td>'.$row["paddress"].'</td></tr>
                <tr><td>Date of Birth:</td><td>'.$row["pdob"].'</td></tr>
            </table>
            <div style="text-align:center;margin-top:20px;">
                <a href="patient.php"><button class="btn-primary-soft btn">OK</button></a>
            </div>
        </div>
    </div>';
}
?>

<!-- JS for Burger Menu -->
<script>
function toggleSidebar() {
    document.querySelector('.menu').classList.toggle('active');
}
</script>
</body>
</html>
