<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up | TDH Management Portal</title>

    <!-- Google Fonts -->
    <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap -->
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Custom Styles -->
    <style>
        body {
            font-family: 'Montserrat', sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }

        .signup-container {
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background: linear-gradient(135deg, #fff 50%, #6a0dad 50%);
            padding: 20px;
        }

        .signup-card {
            background-color: #fff;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0, 0, 0, 0.1);
            width: 100%;
            max-width: 500px;
            padding: 40px;
            position: relative;
            z-index: 1;
        }

        .signup-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            border-radius: 15px;
            background: rgba(106, 13, 173, 0.05);
            z-index: -1;
        }

        .header-text {
            font-size: 2rem;
            font-weight: 700;
            color: #6a0dad;
            text-align: center;
        }

        .sub-text {
            font-size: 1rem;
            color: #555;
            text-align: center;
            margin-bottom: 30px;
        }

        .form-label {
            font-weight: 500;
            color: #6a0dad;
        }

        .input-text {
            width: 100%;
            padding: 12px 15px;
            margin: 5px 0 15px 0;
            border-radius: 8px;
            border: 1px solid #ccc;
            outline: none;
            transition: 0.3s;
        }

        .input-text:focus {
            border-color: #6a0dad;
            box-shadow: 0 0 5px rgba(106, 13, 173, 0.3);
        }

        .login-btn {
            background-color: #6a0dad;
            color: #fff;
            font-weight: 600;
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 8px;
            transition: 0.3s;
        }

        .login-btn:hover {
            background-color: #9b5de5;
        }

        .btn-primary-soft {
            background-color: #f0e6ff;
            color: #6a0dad;
        }

        .btn-primary-soft:hover {
            background-color: #e0d1ff;
        }

        .hover-link1 {
            color: #6a0dad;
            text-decoration: none;
            font-weight: 500;
        }

        .hover-link1:hover {
            color: #9b5de5;
            text-decoration: underline;
        }

        @media (max-width: 768px) {
            .signup-card {
                padding: 30px 20px;
            }

            .header-text {
                font-size: 1.7rem;
            }
        }
    </style>
</head>
<body>

<?php
session_start();

$_SESSION["user"] = "";
$_SESSION["usertype"] = "";

date_default_timezone_set('Asia/Kolkata');
$_SESSION["date"] = date('Y-m-d');

if ($_POST) {
    $_SESSION["personal"] = array(
        'fname' => $_POST['fname'],
        'lname' => $_POST['lname'],
        'address' => $_POST['address'],
        'nic' => $_POST['nic'],
        'dob' => $_POST['dob']
    );

    header("location: create-account.php");
}
?>

<div class="signup-container">
    <div class="signup-card">
        <p class="header-text">Let's Get Started</p>
        <p class="sub-text">Add Your Personal Details to Continue</p>

        <form action="" method="POST">
            <div class="form-row">
                <div class="form-group col-md-6">
                    <label for="fname" class="form-label">First Name</label>
                    <input type="text" name="fname" class="input-text" placeholder="First Name" required>
                </div>
                <div class="form-group col-md-6">
                    <label for="lname" class="form-label">Last Name</label>
                    <input type="text" name="lname" class="input-text" placeholder="Last Name" required>
                </div>
            </div>

            <div class="form-group">
                <label for="address" class="form-label">Address</label>
                <input type="text" name="address" class="input-text" placeholder="Address" required>
            </div>

            <div class="form-group">
                <label for="nic" class="form-label">NIC Number</label>
                <input type="text" name="nic" class="input-text" placeholder="NIC Number" required>
            </div>

            <div class="form-group">
                <label for="dob" class="form-label">Date of Birth</label>
                <input type="date" name="dob" class="input-text" required>
            </div>

            <div class="form-row">
                <div class="form-group col-md-6">
                    <input type="reset" value="Reset" class="login-btn btn-primary-soft btn">
                </div>
                <div class="form-group col-md-6">
                    <input type="submit" value="Next" class="login-btn btn-primary btn">
                </div>
            </div>

            <p class="sub-text mt-3 text-center">Already have an account? 
                <a href="login.php" class="hover-link1">Login</a>
            </p>
        </form>
    </div>
</div>

</body>
</html>
