<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="../css/animations.css">  
<link rel="stylesheet" href="../css/main.css">  
<link rel="stylesheet" href="../css/admin.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">

<title>Admin Dashboard</title>

<style>
/* ---------- Animations ---------- */
.dashbord-tables{ animation: transitionIn-Y-over 0.5s; }
.filter-container{ animation: transitionIn-Y-bottom 0.5s; }
.sub-table{ animation: transitionIn-Y-bottom 0.5s; }

/* ---------- Colors & Sidebar ---------- */
:root {
  --main-color: #6a0dad; /* Purple */
  --hover-color: #580b99;
}

.menu { 
    background-color: var(--main-color);
    color: #fff;
    min-height: 100vh;
    width: 250px;
    transition: transform 0.3s ease;
    position: fixed;
    left: 0;
    top: 0;
}
.menu.active { transform: translateX(0); }
.menu-text { color: #fff; font-size: 15px; }
.menu-btn:hover .menu-text, .menu-active .menu-text { color: #fff; }
.menu-icon { margin-right: 8px; font-size: 16px; }

/* ---------- Layout ---------- */
.container{
    display: flex;
    min-height: 100vh;
    overflow-x: hidden;
}
.dash-body{
    flex: 1;
    padding: 25px;
    background: #f9f9f9;
    margin-left: 250px;
    overflow-y: auto;
    transition: margin-left 0.3s ease;
}
.menu.active + .dash-body { margin-left: 0; }

/* ---------- Dashboard Cards ---------- */
.dashboard-items{
    background: #fff;
    border-radius: 12px;
    display: flex;
    justify-content: space-between;
    align-items: center;
    padding: 25px;
    box-shadow: 0px 2px 5px rgba(0,0,0,0.1);
    transition: transform 0.3s;
}
.dashboard-items:hover{ transform: translateY(-3px); }
.h1-dashboard{ font-size: 28px; font-weight: 700; color: var(--main-color); }
.h3-dashboard{ font-size: 15px; font-weight: 500; color: #333; }
.dashboard-icons{ width: 50px; height: 50px; background-size: cover; }

/* ---------- Toggle Button ---------- */
.menu-toggle{
    display: none;
    background: var(--main-color);
    color: white;
    font-size: 22px;
    padding: 10px 15px;
    border-radius: 8px;
    border: none;
    cursor: pointer;
    transition: background 0.3s;
}
.menu-toggle:hover{ background: var(--hover-color); }

/* ---------- Responsive ---------- */
@media screen and (max-width:1024px){
    .container{ flex-direction: column; }
    .menu{ width: 100%; min-height: auto; position: relative; }
    .dash-body{ margin-left: 0; padding: 15px; }
    .dashboard-items{ flex-direction: column; text-align: center; gap:10px; }
}

@media screen and (max-width:768px){
    .menu{
        position: fixed;
        top: 0;
        left: -100%;
        width: 250px;
        height: 100%;
        z-index: 100;
        box-shadow: 2px 0 10px rgba(0,0,0,0.3);
    }
    .menu.active{
        left: 0;
    }
    .menu-toggle{
        display: block;
        position: fixed;
        top: 10px;
        left: 10px;
        z-index: 200;
    }
    .dash-body{
        margin-left: 0;
        padding-top: 60px;
    }
}

@media screen and (max-width:480px){
    .h1-dashboard{ font-size: 22px; }
    .h3-dashboard{ font-size: 13px; }
    .dashboard-items{ padding: 15px; gap:10px; }
    .dashboard-icons{ width: 40px; height: 40px; }
    .sub-table th, .sub-table td{ font-size: 12px; padding: 6px; }
}
</style>
</head>
<body>

<?php
session_start();
if(isset($_SESSION["user"])){
    if(($_SESSION["user"])=="" or $_SESSION['usertype']!='a'){
        header("location: ../login.php");
    }
}else{
    header("location: ../login.php");
}
include("../connection.php");

date_default_timezone_set('Asia/Kolkata');
$today = date('Y-m-d');

$patientrow = $database->query("SELECT * FROM patient;");
$doctorrow = $database->query("SELECT * FROM doctor;");
$appointmentrow = $database->query("SELECT * FROM appointment WHERE appodate>='$today';");
$schedulerow = $database->query("SELECT * FROM schedule WHERE scheduledate='$today';");
?>

<!-- Sidebar Toggle -->
<button class="menu-toggle" id="menuToggle"><i class="fa-solid fa-bars"></i></button>

<div class="container">

    <!-- Sidebar -->
    <div class="menu" id="sidebar">
        <table class="menu-container" border="0">
            <tr>
                <td style="padding:10px" colspan="2">
                    <table border="0" class="profile-container">
                        <tr>
                            <td width="30%" style="padding-left:20px;">
                                <img src="../img/user.png" alt="Admin" width="100%" style="border-radius:50%;">
                            </td>
                            <td style="padding:0;">
                                <p class="profile-title">Administrator</p>
                                <p class="profile-subtitle">admin@edoc.com</p>
                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">
                                <a href="../logout.php"><input type="button" value="Log out" class="logout-btn btn-primary-soft btn"></a>
                            </td>
                        </tr>
                    </table>
                </td>
            </tr>

            <tr class="menu-row"><td class="menu-btn menu-active"><a href="index.php" class="non-style-link-menu"><p class="menu-text"><i class="fa-solid fa-chart-line menu-icon"></i> Dashboard</p></a></td></tr>
            <tr class="menu-row"><td class="menu-btn"><a href="doctors.php" class="non-style-link-menu"><p class="menu-text"><i class="fa-solid fa-user-doctor menu-icon"></i> Doctors</p></a></td></tr>
            <tr class="menu-row"><td class="menu-btn"><a href="schedule.php" class="non-style-link-menu"><p class="menu-text"><i class="fa-solid fa-calendar-days menu-icon"></i> Schedule</p></a></td></tr>
            <tr class="menu-row"><td class="menu-btn"><a href="appointment.php" class="non-style-link-menu"><p class="menu-text"><i class="fa-solid fa-book menu-icon"></i> Appointment</p></a></td></tr>
            <tr class="menu-row"><td class="menu-btn"><a href="patient.php" class="non-style-link-menu"><p class="menu-text"><i class="fa-solid fa-users menu-icon"></i> Patients</p></a></td></tr>
        </table>
    </div>

    <!-- Dashboard Body -->
    <div class="dash-body">

        <div class="nav-bar">
            <form action="doctors.php" method="post" class="header-search" style="flex:1;">
                <input type="search" name="search" class="input-text header-searchbar" placeholder="Search Doctor name or Email" list="doctors">
                <?php
                echo '<datalist id="doctors">';
                $list11 = $database->query("SELECT docname, docemail FROM doctor;");
                while($row00=$list11->fetch_assoc()){
                    echo "<option value='".$row00["docname"]."'><option value='".$row00["docemail"]."'>";
                }
                echo '</datalist>';
                ?>
                <input type="Submit" value="Search" class="login-btn btn-primary-soft btn">
            </form>
            <div style="text-align:right;">
                <p style="font-size:14px;color:#777;">Today's Date</p>
                <p class="heading-sub12"><?php echo $today; ?></p>
            </div>
        </div>

        <!-- Status Cards -->
        <div class="filter-container" style="margin-top:20px;">
            <p style="font-size:20px;font-weight:600;">Status</p>
            <div style="display:flex;flex-wrap:wrap;gap:20px;">
                <div class="dashboard-items"><div><div class="h1-dashboard"><?php echo $doctorrow->num_rows; ?></div><div class="h3-dashboard">Doctors</div></div><div class="dashboard-icons" style="background-image:url('../img/icons/doctors-hover.svg');"></div></div>
                <div class="dashboard-items"><div><div class="h1-dashboard"><?php echo $patientrow->num_rows; ?></div><div class="h3-dashboard">Patients</div></div><div class="dashboard-icons" style="background-image:url('../img/icons/patients-hover.svg');"></div></div>
                <div class="dashboard-items"><div><div class="h1-dashboard"><?php echo $appointmentrow->num_rows; ?></div><div class="h3-dashboard">New Bookings</div></div><div class="dashboard-icons" style="background-image:url('../img/icons/book-hover.svg');"></div></div>
                <div class="dashboard-items"><div><div class="h1-dashboard"><?php echo $schedulerow->num_rows; ?></div><div class="h3-dashboard">Today Sessions</div></div><div class="dashboard-icons" style="background-image:url('../img/icons/session-iceblue.svg');"></div></div>
            </div>
        </div>

        <!-- Upcoming Appointments & Sessions -->
        <div style="margin-top:40px;">
            <table width="100%" border="0" class="dashbord-tables">
                <tr>
                    <td width="50%">
                        <h3>Upcoming Appointments (Next 7 Days)</h3>
                        <div class="abc scroll" style="height:200px;">
                            <table width="100%" class="sub-table scrolldown">
                                <thead><tr><th>App No</th><th>Patient</th><th>Doctor</th><th>Session</th></tr></thead>
                                <tbody>
                                <?php
                                $nextweek=date("Y-m-d",strtotime("+1 week"));
                                $sqlmain= "SELECT appointment.apponum, patient.pname, doctor.docname, schedule.title 
                                           FROM appointment 
                                           INNER JOIN schedule ON appointment.scheduleid=schedule.scheduleid 
                                           INNER JOIN patient ON appointment.pid=patient.pid 
                                           INNER JOIN doctor ON schedule.docid=doctor.docid 
                                           WHERE schedule.scheduledate>='$today' AND schedule.scheduledate<='$nextweek'";
                                $result= $database->query($sqlmain);
                                if($result->num_rows==0){
                                    echo "<tr><td colspan='4' style='text-align:center;'>No appointments found.</td></tr>";
                                }else{
                                    while($row=$result->fetch_assoc()){
                                        echo "<tr><td>{$row['apponum']}</td><td>{$row['pname']}</td><td>{$row['docname']}</td><td>{$row['title']}</td></tr>";
                                    }
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </td>

                    <td width="50%">
                        <h3>Upcoming Sessions (Next 7 Days)</h3>
                        <div class="abc scroll" style="height:200px;">
                            <table width="100%" class="sub-table scrolldown">
                                <thead><tr><th>Session</th><th>Doctor</th><th>Date & Time</th></tr></thead>
                                <tbody>
                                <?php
                                $sqlmain2= "SELECT title, docname, scheduledate, scheduletime 
                                            FROM schedule 
                                            INNER JOIN doctor ON schedule.docid=doctor.docid 
                                            WHERE scheduledate>='$today' AND scheduledate<='$nextweek'";
                                $result2= $database->query($sqlmain2);
                                if($result2->num_rows==0){
                                    echo "<tr><td colspan='3' style='text-align:center;'>No sessions found.</td></tr>";
                                }else{
                                    while($row=$result2->fetch_assoc()){
                                        echo "<tr><td>{$row['title']}</td><td>{$row['docname']}</td><td>{$row['scheduledate']} {$row['scheduletime']}</td></tr>";
                                    }
                                }
                                ?>
                                </tbody>
                            </table>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</div>

<script>
document.getElementById('menuToggle').addEventListener('click',()=>{
    document.getElementById('sidebar').classList.toggle('active');
});
</script>

</body>
</html>
