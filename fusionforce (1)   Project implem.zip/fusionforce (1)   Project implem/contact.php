<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <title>Contact Us | TDH Management Portal</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css2?family=Montserrat:wght@300;400;500;600;700&display=swap" rel="stylesheet">

  <!-- Bootstrap and Font Awesome -->
  <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

  <!-- Custom CSS -->
  <style>
    body {
      font-family: 'Montserrat', sans-serif;
      background-color: #fff;
      color: #333;
    }

    .navbar-dark .navbar-nav .nav-link {
      color: #6a0dad !important;
      font-weight: 500;
    }

    .navbar-dark .navbar-nav .nav-link:hover {
      color: #9b5de5 !important;
    }

    .contact {
      background-color: #fdfdfd;
      color: #333;
    }

    .form-control {
      border: none;
      border-radius: 0;
      border-bottom: 2px solid #ccc;
      background-color: #fff;
      color: #333;
    }

    .form-control:focus {
      border-color: #6a0dad;
      box-shadow: none;
      color: #333;
    }

    .btn-primary {
      background-color: #6a0dad;
      border: none;
      color: #fff;
      font-weight: 600;
    }

    .btn-primary:hover {
      background-color: #9b5de5;
    }

    .map-card {
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 4px 20px rgba(106, 13, 173, 0.3);
      margin-bottom: 30px;
    }

    .map-card iframe {
      width: 100%;
      height: 350px;
      border: 0;
    }

    .footer {
      background-color: #6a0dad;
      color: #fff;
      padding-top: 40px;
      padding-bottom: 20px;
    }

    .footer a {
      color: #fff;
      text-decoration: none;
    }

    .footer a:hover {
      color: #9b5de5;
    }

    .back-to-top {
      position: fixed;
      bottom: 20px;
      right: 20px;
      background: #6a0dad;
      color: #fff;
      padding: 10px;
      border-radius: 50%;
      display: none;
      z-index: 99;
    }

    .back-to-top:hover {
      background: #9b5de5;
    }

    @media (max-width: 992px) {
      .map-card iframe {
        height: 300px;
      }
    }

    @media (max-width: 768px) {
      .map-card iframe {
        height: 250px;
      }

      .contact h2 {
        font-size: 1.8rem;
      }

      .btn-primary {
        padding: 10px 20px;
      }
    }

    @media (max-width: 480px) {
      .map-card iframe {
        height: 200px;
      }

      .contact h2 {
        font-size: 1.5rem;
      }

      .btn-primary {
        width: 100%;
        padding: 12px 0;
      }

      .navbar-nav {
        text-align: center;
      }
    }
  </style>
</head>

<body>

  <!-- Navigation Bar -->
  <nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <a class="navbar-brand" href="index.html">
      <!-- Logo or name can go here -->
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse justify-content-end" id="navbarCollapse">
      <div class="navbar-nav">
        <a href="index.html" class="nav-item nav-link">Go back</a>
      </div>
    </div>
  </nav>

  <!-- Contact Section -->
  <section class="contact py-5" id="contact">
    <div class="container">
      <div class="text-center mb-5">
        <h2 class="fw-bold" style="color:#6a0dad;">Get in Touch</h2>
        <p>If you have any questions, feel free to contact us.</p>
      </div>
      <div class="row justify-content-center">
        <div class="col-lg-8">
          <form action="https://api.web3forms.com/submit" method="POST">
            <input type="hidden" name="access_key" value="b6243407-7f9d-4ba4-87b6-3e3e0819d0d9">
            <div class="form-group">
              <input type="text" class="form-control" name="name" placeholder="Your Name" required>
            </div>
            <div class="form-group">
              <input type="email" class="form-control" name="email" placeholder="Gmail Address" required
                pattern="[a-zA-Z0-9._%+-]+@gmail\.com$"
                title="Only Gmail addresses allowed (e.g. name@gmail.com)">
            </div>
            <div class="form-group">
              <input type="text" class="form-control" name="subject" placeholder="Subject" required>
            </div>
            <div class="form-group">
              <textarea class="form-control" name="message" rows="5" placeholder="Your Message" required></textarea>
            </div>
            <div class="text-center">
              <button type="submit" class="btn btn-primary px-5 py-2">Send Message</button>
            </div>
          </form>
        </div>
      </div>

      <!-- Map Card -->
      <div class="map-card mt-5">
        <iframe
          src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3303.55526411102!2d23.465!3d-27.456!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1e8b1d75a5f9e3b1%3A0x123456789abcdef!2sTDH%20Management%20Portal%2C%20Kuruman!5e0!3m2!1sen!2sza!4v1699300000000!5m2!1sen!2sza"
          allowfullscreen="" loading="lazy"></iframe>
      </div>
    </div>
  </section>

  <!-- Footer -->
  <footer class="footer pt-5">
    <div class="container">
      <div class="row g-5">
        <div class="col-lg-4">
          <h5>Contact Information</h5>
          <p><i class="fas fa-map-marker-alt"></i> Cape Town, Western Cape, South Africa</p>
          <p><i class="fas fa-envelope"></i> Lilliesyntiche@gmail.com</p>
          <p><i class="fas fa-phone"></i> 0629915504</p>
        </div>
        <div class="col-lg-4">
          <h5>Quick Links</h5>
          <a href="index.html" class="d-block">Go back</a>
          <a href="#contact" class="d-block">Contact Us</a>
        </div>
        <div class="col-lg-4 text-center">
          <img src="img/Tiche logo.png" class="mb-3" alt="Logo" style="width:80px; border-radius:50%;">
          <p class="mb-0">&copy; 2025 All Rights Reserved. Developed by <a href="#" class="fw-bold">Fusion force</a>.</p>
        </div>
      </div>
    </div>
  </footer>

  <!-- Back to Top -->
  <a href="#" class="btn back-to-top"><i class="fa fa-chevron-up"></i></a>

  <!-- Loader -->
  <div id="loader" class="show">
    <div class="loader"></div>
  </div>

  <!-- Scripts -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
  <script>
    $(window).scroll(function () {
      if ($(this).scrollTop() > 100) {
        $('.back-to-top').fadeIn('slow');
      } else {
        $('.back-to-top').fadeOut('slow');
      }
    });

    $('.back-to-top').click(function () {
      $('html, body').animate({ scrollTop: 0 }, 800);
      return false;
    });

    $(window).on('load', function () {
      $('#loader').fadeOut('slow');
    });
  </script>

</body>
</html>

